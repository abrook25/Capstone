﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PriceTracker.Data
{
    public class DisplayItem
    {
        public string ItemName { get; set; }
        public double ItemPrice { get; set; }
        public string ItemLink { get; set; }
        public string ItemImage { get; set; }
        public string ItemSource { get; set; }
        public string ItemEbayId { get; set; }

    }
}
